import 'dart:convert';
import 'dart:io';

import 'learn_models.dart';

/// Պահում է օգտատերերին և յուրաքանչյուրի առաջընթացը առանձին ֆայլում։
class LearnRepository {
  LearnRepository({Directory? directory}) : _directory = directory;

  static const accountsFile = 'learn.accounts.json';

  final Directory? _directory;

  Directory get _dir {
    final directory = _directory ?? _defaultDirectory();
    if (!directory.existsSync()) {
      directory.createSync(recursive: true);
    }
    return directory;
  }

  Directory _defaultDirectory() {
    final base = Platform.environment['LOCALAPPDATA'] ??
        Platform.environment['HOME'] ??
        Directory.systemTemp.path;
    return Directory('$base${Platform.pathSeparator}Usoum');
  }

  File _file(String name) => File('${_dir.path}${Platform.pathSeparator}$name');

  Future<({List<LearnAccount> accounts, String? currentId})> loadAccounts() async {
    try {
      final file = _file(accountsFile);
      if (!file.existsSync()) return (accounts: <LearnAccount>[], currentId: null);
      final raw = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      final accounts = (raw['users'] as List<dynamic>? ?? const [])
          .map((e) => LearnAccount.fromJson(e as Map<String, dynamic>))
          .toList();
      return (accounts: accounts, currentId: raw['currentId'] as String?);
    } catch (_) {
      return (accounts: <LearnAccount>[], currentId: null);
    }
  }

  Future<void> saveAccounts(List<LearnAccount> accounts, String? currentId) async {
    try {
      await _file(accountsFile).writeAsString(jsonEncode({
        'users': accounts.map((a) => a.toJson()).toList(),
        'currentId': currentId,
      }));
    } catch (_) {
      throw StateError('Չհաջողվեց պահել հաշիվները։');
    }
  }

  Future<LearnProfile> loadProfile(String userId) async {
    try {
      final file = _file('learn.profile.$userId.json');
      if (!file.existsSync()) return LearnProfile(userId: userId);
      return LearnProfile.fromJson(
        jsonDecode(await file.readAsString()) as Map<String, dynamic>,
      );
    } catch (_) {
      return LearnProfile(userId: userId);
    }
  }

  Future<void> saveProfile(LearnProfile profile) async {
    try {
      await _file('learn.profile.${profile.userId}.json')
          .writeAsString(jsonEncode(profile.toJson()));
    } catch (_) {
      throw StateError('Չհաջողվեց պահել առաջընթացը։');
    }
  }
}
